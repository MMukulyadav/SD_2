"use strict";

// Include the app.js file.
// This will run the code.
console.log("entrypoint");
const app = require("./app/app.js");